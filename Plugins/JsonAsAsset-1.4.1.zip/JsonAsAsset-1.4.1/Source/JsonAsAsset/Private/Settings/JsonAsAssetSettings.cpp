/* Copyright JsonAsAsset Contributors 2024-2026 */

#include "Settings/JsonAsAssetSettings.h"
#include "Modules/Metadata.h"
#include "Widgets/Input/SButton.h"
#include "Widgets/SBoxPanel.h"

FName GJsonAsAssetSettingsCategoryName = FName("General");

UJsonAsAssetSettings::UJsonAsAssetSettings() {
	CategoryName = GJsonAsAssetSettingsCategoryName;
	SectionName = GJsonAsAssetName;
}

FText UJsonAsAssetSettings::GetSectionText() const {
	return FText::FromString(GJsonAsAssetName.ToString());
}